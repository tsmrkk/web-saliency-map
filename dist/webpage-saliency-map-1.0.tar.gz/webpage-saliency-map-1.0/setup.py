# coding: utf-8
from setuptools import setup

setup(
    name="webpage-saliency-map",
    version='1.0',
    description='ウェブページの顕著性マップ生成',
    author='Yuya Inagaki',
    author_email='yuya.ina56@gmail.com',
    url='https://github.com/yuya-inagaki/web-saliency-map',
)

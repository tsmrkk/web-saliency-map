import webpage_saliency_map as webpage_saliency_map

def execute():
    webpage_saliency_map.main()